CREATE DATABASE Kasir
GO
USE Kasir
GO

CREATE TABLE Product (
	ProductID CHAR (5) PRIMARY KEY CHECK (ProductID LIKE 'PO[0-9][0-9][0-9]') NOT NULL,
	ProductName VARCHAR(100) NOT NULL,
	ProductQty INT NOT NULL,
	Price INT NOT NULL
)

CREATE TABLE Customer(
	CustomerID CHAR(5) PRIMARY KEY CHECK(CustomerID like 'CU[0-9][0-9][0-9]')NOT NULL,
	CustomerName VARCHAR(50) NOT NULL,
	Age INT NOT NULL,
	PhoneNum VARCHAR(50) NOT NULL,
	Email VARCHAR(50) NOT NULL,
)
CREATE TABLE TransactionHeader(
	TransactionID CHAR(5) PRIMARY KEY CHECK (TransactionID like 'TR[0-9][0-9][0-9]')NOT NULL,
	CustomerID CHAR(5) FOREIGN KEY REFERENCES Customer(CustomerID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	TransactionDate DATE NOT NULL,
)


CREATE TABLE TransactionDetail (
	TransactionID CHAR(5) FOREIGN KEY REFERENCES TransactionHeader(TransactionID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	ProductID CHAR(5) FOREIGN KEY REFERENCES Product(ProductID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	Qty INT NOT NULL,
	PRIMARY KEY(TransactionID, ProductID)
)


INSERT INTO Product (ProductID, ProductName, ProductQty, Price) VALUES
('PO001','Roti Isi',100,5000),
('PO002','LPG',100,25000),
('PO003','Air Galon',100,20000),
('PO004','Minyak Goreng',100,14000),
('PO005','Garam',100,5000),
('PO006','Mie Instan',100,2000),
('PO007','Beras',100,10000),
('PO008','Air Galon',100,20000),
('PO009','Deterjen Bubuk',100,20000),
('PO010','Sabun Batang',100,6000);


INSERT INTO Customer (CustomerID, CustomerName, Age, PhoneNum, Email)VALUES
('CU001', 'Alex Mason', 44, '082375368309', 'AlexMason1933@gmail.com'),
('CU002', 'Dwight Fairfield', 21, '087294603745', 'DwightFF@gmail.com'),
('CU003', 'Way Jon', 20, '081390654251', 'WayJon2020@gmail.com'),
('CU004', 'Yassine Taoufik', 24, '081722398743', 'YassineTF@gmail.com'),
('CU005', 'Erick Priadi', 20, '081578069532', 'ErickPriadi@gmail.com');


INSERT INTO TransactionHeader VALUES('TR001','CU001',GETDATE())

INSERT INTO TransactionDetail VALUES ('TR001','PO001',10)